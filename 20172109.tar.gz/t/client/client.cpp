#include<stdio.h>
#include<sys/types.h>
#include<string.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<iostream>
using namespace std;
int main(int argc,char**argv)
{
int sockfd;
char fname[25];
int len;
struct sockaddr_in servaddr;


string client_alias=argv[1];
string client_ip=argv[2];
string client_port=argv[3];
string server_ip=argv[4];
string server_port=argv[5];
string downloading_port=argv[6];
string client_root=argv[7];

string inputstring;


sockfd=socket(AF_INET,SOCK_STREAM,0);
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=inet_addr(argv[4]);
servaddr.sin_port=htons(atoi(argv[5]));
connect(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr));
cout<<"INSERT IN THE FORMAT"<<endl;
cout<<"search filename"<<endl;
cout<<"get [entry_number] output_file_name"<<endl;
cout<<"get client_alias relative_path output_file_name"<<endl;
cout<<"share relative_path_to_file_wrt_client"<<endl; 
cout<<"del relative_path_to_file_wrt_client"<<endl;
cout<<"exec client_alias shell_command"<<endl;

char buffer[1000]={'\0'};
cout<<"this is client"<<endl;
for(int k=1;k<8;k++)
{
strcpy(buffer,argv[k]);
//puts(buffer);
write(sockfd,buffer,sizeof(buffer));
memset(buffer,'\0',strlen(buffer));
}

while(read(STDIN_FILENO,buffer,sizeof(buffer))>0)
    {
	send(sockfd , buffer , strlen(buffer) , 0);
	memset(buffer,'\0',strlen(buffer));
	read(sockfd,buffer,sizeof(buffer));
	cout<<buffer<<endl;	
	memset(buffer,'\0',strlen(buffer));
		
    }


cout<<"the file entry was sent successfully";

}
