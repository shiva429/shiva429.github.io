#include<stdio.h>
#include<string.h>	//strlen
#include<stdlib.h>	
#include<sys/socket.h>
#include<arpa/inet.h>	//inet_addr
#include<unistd.h>	//writett
#include <netinet/in.h>
#include<pthread.h> //for threading , link with lpthread
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;

void *connection_handler(void *);

int main(int argc , char *argv[])
{
int fd,connfd;
socklen_t client;
int *new_sock;
//********************************
string server_ip=argv[1]; 
string server_port=argv[2]; 
string main_repofile=argv[3]; 
string client_list_file=argv[4];
string server_root=argv[5];

string inputstring,isparts[4];

//**********************************

struct sockaddr_in servaddr,cliaddr;
fd=socket(AF_INET,SOCK_STREAM,0);
bzero(&servaddr,sizeof(servaddr));
servaddr.sin_family=AF_INET;
servaddr.sin_addr.s_addr=inet_addr(argv[1]);
servaddr.sin_port=htons(atoi(argv[2]));
bind(fd,(struct sockaddr*)&servaddr,sizeof(servaddr));
listen(fd,5);
client=sizeof(cliaddr);

int new_socket;
while(new_socket=accept(fd,(struct sockaddr*)&cliaddr,(socklen_t*)&client))
	{
		puts("Connection accepted");
		pthread_t sniffer_thread;
		new_sock =(int *) malloc(1);
		*new_sock = new_socket;
		
		if( pthread_create( &sniffer_thread , NULL ,  connection_handler , (void*) new_sock) < 0)
		{
			perror("could not create thread");
			return 1;
		}
		
		puts("Handler assigned");
	}
	
	if (new_socket<0)
	{
		perror("accept failed");
		return 1;
	}
	
	return 0;
}





void *connection_handler(void *socket_desc)
{
	int connfd = *(int*)socket_desc;
	int read_size;


map< pair< string , string >,string > m;

pair<string, string> p1;


string inputstring,isparts[4];
char buffer[1000]={'\0'};
string client_args[7];

string token;
string filename;
string fullpath;
string alias;
string delimiter = "/";
size_t pos = 0;
char nextline[]="\n";


//client_alias=client_args[0];
//client_ip=client_args[1];
//client_port=client_args[2];
//server_ip=client_args[3];
//server_port=client_args[4];
//downloading_port=client_args[5];
//client_root=client_args[6];








//FILE *fp;
//fp=fopen("add.txt","a");

//read(connfd,buffer,sizeof(buffer));
//write(connfd , buffer , sizeof(buffer));

//char nextline[]="\n";
for(int k=0;k<7;k++)
{
read(connfd , buffer , sizeof (buffer));

client_args[k]=buffer;
//puts(buffer);
	memset(buffer,'\0',strlen(buffer));
}



while((read_size=read(connfd,buffer,sizeof(buffer)))>0)	
{
puts(buffer);
inputstring=buffer;
int z=0,y=0;
while ((z = inputstring.find(" ")) != string::npos) {
    isparts[y++]=inputstring.substr(0,z);
    inputstring.erase(0, z + 1);
}
isparts[y]=inputstring;

if(!(isparts[0].compare("search")))
{
//**********************
string srchfn;pos=0;
string srchpath=isparts[1];
while ((pos = srchpath.find(delimiter)) != string::npos) {
    token = srchpath.substr(0, pos);
    srchpath.erase(0, pos + delimiter.length());	
}
srchfn=srchpath;
int seq=0;
cout<<"alias	filepath	filename"<<endl;
for (const auto& p : m)
{
string uppsecond,upsrchfn;
uppsecond=p.second;
upsrchfn=srchfn;
transform(uppsecond.begin(), uppsecond.end(),uppsecond.begin(), ::tolower);
transform(upsrchfn.begin(), upsrchfn.end(), upsrchfn.begin(), ::tolower);
if(!(uppsecond.compare(0,upsrchfn.length(),upsrchfn)))
{seq++;
cout<<seq<<" "<<p.first.first <<"\t"<<p.first.second <<"\t"<<p.second<<endl;
}
}
cout<<"successfully searched";

//**********************
strcpy(buffer,"you asked to search");
write(connfd , buffer , sizeof(buffer));
}








else if(!(isparts[0].compare("get")))
{
strcpy(buffer,"you asked for get");
write(connfd , buffer , sizeof(buffer));
}









else if(!(isparts[0].compare("share")))
{

//****************
fullpath=isparts[1];
int count=0;
while ((pos = fullpath.find(delimiter)) != string::npos) {
    token = fullpath.substr(0, pos);
    fullpath.erase(0, pos + delimiter.length());
}
filename=fullpath;
pair<string, string> p1;
p1=make_pair(client_args[0],isparts[1]);
m.insert(std::make_pair(p1, filename));


//****************
strcpy(buffer,"it is share");
write(connfd , buffer , sizeof(buffer));
}
else if(!(isparts[0].compare("del")))
{

//****************
string delfp=isparts[1];

for (const auto& p : m)
{
if(!(p.first.second.compare(delfp)))
{
cout<<p.first.first <<"\t"<<p.first.second <<"\t"<<p.second<<endl;
m.erase(p.first);
}
}


//****************
strcpy(buffer,"it is del");
write(connfd , buffer , sizeof(buffer));
}
else if(!(isparts[0].compare("exec")))
{
strcpy(buffer,"it is exec");
write(connfd , buffer , sizeof(buffer));
}
else
{
strcpy(buffer,"INVALID");
write(connfd , buffer , sizeof(buffer));
}
//fprintf(fp,"%s",buffer);
//fprintf(fp,"%s",nextline);
cout<<endl<<"final map"<<endl;
FILE *fp;
fp=fopen("cliententry.txt","a");
memset(buffer,'\0',strlen(buffer));
for (const auto& p : m)
{
std::cout<<"\n"<<p.first.first << "\t"<<p.first.second<<"\t" << p.second;
strncpy(buffer,p.second.c_str(),strlen(p.second.c_str())-1);
strcat(buffer,":");
strncat(buffer,p.first.second.c_str(),strlen(p.first.second.c_str())-1);
strcat(buffer,":");
strcat(buffer,p.first.first.c_str());
fprintf(fp,"%s",nextline);
fprintf(fp,"%s",buffer);
memset(buffer,'\0',strlen(buffer));

}
fclose(fp);



}
//***********************

	
	if(read_size == 0)
	{
		puts("Client disconnected");
		fflush(stdout);
	}
	else if(read_size == -1)
	{
		perror("recv failed");
	}
		
	free(socket_desc);



memset(buffer,'\0',strlen(buffer));



	return 0;
}
